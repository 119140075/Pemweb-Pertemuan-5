-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2022 at 12:35 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `belajar_ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` bigint(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `prodi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `prodi`) VALUES
(11915006, 'Galih Indra', 'Teknik Elektro'),
(119140026, 'Asyroful Yusuf', 'Teknik Informatika'),
(119140038, 'Ridho Liwardana', 'Teknik Informatika'),
(119140049, 'Hafizh Londata', 'Teknik Informatika'),
(119140057, 'Heksa Dananjaya', 'Teknik Informatika'),
(119140075, 'Makruf Alkarkhi', 'Teknik Informatika'),
(119140081, 'Dodi Devrian', 'Teknik Informatika'),
(119140099, 'Ilham Ijra', 'Teknik Informatika'),
(119140100, 'Junior Robert', 'Teknik Informatika'),
(119140102, 'Ajril Hanif', 'Teknik Informatika'),
(119140138, 'Hamas Azhar', 'Teknik Informatika'),
(119150001, 'Rendy Afhan', 'Teknik Elektro'),
(119150016, 'Angga Panjaitan', 'Teknik Elektro'),
(119150026, 'Firman Utina', 'Teknik Elektro'),
(119150033, 'Jihan Aliandra', 'Teknik Elektro'),
(119150048, 'Ariel Tarigan', 'Teknik Elektro'),
(119150068, 'Justin Damanri', 'Teknik Elektro'),
(119150075, 'Muhammad Farhan', 'Teknik Elektro'),
(119150083, 'Norman Kiro', 'Teknik Elektro'),
(119150095, 'Helena Inggit', 'Teknik Elektro'),
(119214007, 'Jindan Hira', 'Teknik Sipil'),
(119214033, 'Gama Erwan', 'Teknik Sipil'),
(119214044, 'Andaru Bintang', 'Teknik Sipil'),
(119214055, 'Tian Pasaribu', 'Teknik Sipil'),
(119214056, 'Sinra Juan', 'Teknik Sipil');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `nim` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2313131240;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
